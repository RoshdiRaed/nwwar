<?php
// تفعيل عرض الأخطاء للتشخيص
error_reporting(E_ALL);
ini_set('display_errors', 1);

// إعداد headers الضرورية
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// التحقق من طريقة الطلب
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'status' => 'danger', 
        'message' => 'طلب غير صالح - يجب استخدام POST'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// التحقق من وجود الملف
if (!isset($_FILES['code_file'])) {
    echo json_encode([
        'status' => 'danger', 
        'message' => 'لم يتم العثور على الملف في الطلب'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$file = $_FILES['code_file'];

// التحقق من أخطاء الرفع
switch ($file['error']) {
    case UPLOAD_ERR_OK:
        break;
    case UPLOAD_ERR_NO_FILE:
        echo json_encode([
            'status' => 'danger', 
            'message' => 'لم يتم اختيار ملف للرفع'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    case UPLOAD_ERR_INI_SIZE:
    case UPLOAD_ERR_FORM_SIZE:
        echo json_encode([
            'status' => 'danger', 
            'message' => 'حجم الملف كبير جداً'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    default:
        echo json_encode([
            'status' => 'danger', 
            'message' => 'خطأ غير معروف أثناء رفع الملف: ' . $file['error']
        ], JSON_UNESCAPED_UNICODE);
        exit;
}

// التحقق من امتداد الملف
$ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
$allowedExtensions = ['zip', 'rar', 'tar', 'gz'];

if (!in_array($ext, $allowedExtensions)) {
    echo json_encode([
        'status' => 'danger', 
        'message' => 'امتداد الملف غير مدعوم. الامتدادات المدعومة: ' . implode(', ', $allowedExtensions)
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// التحقق من حجم الملف (مثلاً 10 ميجابايت كحد أقصى)
$maxFileSize = 10 * 1024 * 1024; // 10MB
if ($file['size'] > $maxFileSize) {
    echo json_encode([
        'status' => 'danger', 
        'message' => 'حجم الملف كبير جداً. الحد الأقصى: 10 ميجابايت'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// إنشاء مجلد التخزين
$uploadDir = __DIR__ . '/uploads/';
if (!is_dir($uploadDir)) {
    if (!mkdir($uploadDir, 0755, true)) {
        echo json_encode([
            'status' => 'danger', 
            'message' => 'فشل في إنشاء مجلد التخزين'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

// التحقق من أذونات الكتابة
if (!is_writable($uploadDir)) {
    echo json_encode([
        'status' => 'danger', 
        'message' => 'مجلد التخزين غير قابل للكتابة'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// إنشاء اسم ملف آمن وفريد
$filename = date('Y-m-d_H-i-s') . '_' . uniqid() . '.' . $ext;
$filepath = $uploadDir . $filename;

// التحقق من عدم وجود ملف بنفس الاسم (احتياط إضافي)
while (file_exists($filepath)) {
    $filename = date('Y-m-d_H-i-s') . '_' . uniqid() . '.' . $ext;
    $filepath = $uploadDir . $filename;
}

// نقل الملف
if (move_uploaded_file($file['tmp_name'], $filepath)) {
    // التحقق من نجح النقل فعلاً
    if (file_exists($filepath)) {
        echo json_encode([
            'status' => 'success', 
            'message' => 'تم رفع الملف بنجاح!',
            'filename' => $filename,
            'path' => 'uploads/' . $filename,
            'size' => formatBytes($file['size'])
        ], JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode([
            'status' => 'danger', 
            'message' => 'فشل في التحقق من الملف بعد الرفع'
        ], JSON_UNESCAPED_UNICODE);
    }
} else {
    echo json_encode([
        'status' => 'danger', 
        'message' => 'فشل في نقل الملف إلى المجلد النهائي'
    ], JSON_UNESCAPED_UNICODE);
}

// دالة مساعدة لتنسيق حجم الملف
function formatBytes($size, $precision = 2) {
    $units = ['B', 'KB', 'MB', 'GB'];
    
    for ($i = 0; $size > 1024 && $i < count($units) - 1; $i++) {
        $size /= 1024;
    }
    
    return round($size, $precision) . ' ' . $units[$i];
}
?>